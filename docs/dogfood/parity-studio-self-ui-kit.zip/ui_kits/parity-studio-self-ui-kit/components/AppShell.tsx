export interface AppShellProps {
  title?: string;
}

export function AppShell({ title = "Parity Studio — image to verified ui_kit" }: AppShellProps) {
  return (
    <main className="parity-platform-capture" aria-label={title}>
      <header className="parity-platform-capture__notice">
        <p>Platform capture fallback</p>
        <h1>{title}</h1>
        <p>
          The visual source is preserved in ui_kits/parity-studio-self-ui-kit/index.html. Use this
          component as the integration anchor when replacing fallback markup with
          hand-authored React regions.
        </p>
      </header>
    </main>
  );
}
