# parity-studio-self-ui-kit ui_kit

This kit was created from an existing platform route:

- Source URL: http://127.0.0.1:4191/
- Source title: Parity Studio — image to verified ui_kit
- Decompose model attempted: gpt-5-mini
- Fallback mode: deterministic platform capture

## What happened

The model call did not return parseable path-fenced ui_kit files, so the MCP
server preserved the captured route HTML as the canonical visual source in
`index.html` instead of failing the workflow. This lets the kit import into
Parity Studio immediately for inspiration, comments, scoped edits, and export.

## Visible text sample

P Parity Studio V0.1.0 📁 Projects / New design session Comment on preview 50% 75% 100% 125% 150% Export English 简体中文 1 Start 2 Create 3 Improve 4 Verify 5 Export New run Keys and BYOK Projects no projects in this tab yet Recent runs 0 no runs yet Run status 0 status telemetry appears here after a run starts parity-studio Pro PROMPT / IMAGE / UI_KIT ZIP Start new run Balanced AI default - Recommended quality and cost cmd/ctrl + enter to run - ~$0.10-0.80 per pipeline balanced router Agent stream chat + tool calls for selected run GitHub Start a run to chat. The agent edits any file in the canonical shape via tool calls. Start or import a source below. Files Preview Inspiration NEW DESIGN SESSION Image to verified ui_kit, in six steps. Drop a sketch. Watch the agent break it into real components. Comment, iterate, export — every step honest, every cost shown, every parity check named. 01 Drop an image, a kit zip, or generate one gpt-image-2 image, a canonical ui_kit/<slug>/ zip, or sparkles ✨ to generate from a prompt. Drop-zip imports skip generate + decompose entirely. 02 Break it into UI components Exact parity, not approximations. The decomposer emits real .tsx components + tokens.css. 03 Select a component Click any file in the tree — the next comment scopes to that component, not the whole artifact. 04 Comment on it Drop a pinned bbox on the rendered preview, or a free-form note. Comment mode lives in the top-right. 05 Iterate the scoped slice Iterate now folds your comment + selected file into a re-decompose. The previous bundle stays intact. 06 Export as a ui design kit One-click ZIP of the ui_kit/<slug>/ tree — handoff to Claude Code / Cursor / Windsurf. Start from the source composer in the left agent rail PARITY COACH 0/100 Parity score Status: IdleQuality gate: 0/4 repairs, target 14/16 End-user impact readout Refresh Ask agent to fix this Readout: No parity report yet. End-user impact: we cannot judge whether users would trust, understand, or click throu

## Next edit recommendation

Use Parity Studio comments to mark the first area to componentize. Replace the
fallback AppShell anchor with meaningful React regions only after checking
Preview against the preserved `index.html` source.

## Known limitations

- Component decomposition is intentionally minimal because this was a fallback.
- `index.html` is the source of visual truth for the imported run.
- Run a follow-up decompose with a stricter model when you want full component
  decomposition from the preserved capture.
