# parity-studio-self-ui-kit QA plan

## Browser routes

- `http://127.0.0.1:4191/`

## Stable selectors

- Add stable selectors for primary navigation, hero/content, CTA, comments, and export.

## Required checks

- [ ] Run static lint on edited kit files.
- [ ] Open the target route in a live browser and check for console errors.
- [ ] Compare source and generated render for visible text, structure, spacing, and interaction states.
- [ ] Exercise the primary CTA and any newly wired API path in mock and live modes when applicable.
- [ ] Confirm console errors are 0.
- [ ] Capture before/after screenshots for meaningful visual edits.
- [ ] Check horizontal/vertical overflow at desktop and mobile widths.
