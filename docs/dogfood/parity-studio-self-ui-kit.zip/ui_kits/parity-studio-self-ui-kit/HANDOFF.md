# parity-studio-self-ui-kit — handoff to your coding agent

This bundle was produced by parity-studio-mcp. To integrate:

1. Unzip into your repo at the path of your choice.
2. Open in Claude Code, Cursor, or Windsurf and run:

   > Integrate the ui_kits/parity-studio-self-ui-kit/ folder into the existing app at <your route>.
   > First read ui_kits/parity-studio-self-ui-kit/parity.contract.json, performance.budget.json,
   > api-wiring.plan.md, qa.plan.md, and AGENTS.md.
   > Use components/*.tsx as the building blocks. Wire tokens.css into your global stylesheet.
   > Preserve all visible text and numbers verbatim - they came from the source mockup.

3. Verify visually before merging. If parity drifted, run parity_verify with the
   integrated render to surface gaps.

manifest.json schemaVersion 1 contract is stable across minor versions.
