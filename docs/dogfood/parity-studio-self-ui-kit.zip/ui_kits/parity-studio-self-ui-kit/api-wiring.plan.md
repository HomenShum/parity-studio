# parity-studio-self-ui-kit API wiring plan

## Mode

Plan first. Do not replace mock/static data with live calls until endpoints,
auth, loading states, error states, and approval gates are explicit.

## Required env vars

- None declared yet. Add names here before wiring live APIs.

## Live wiring checklist

- [ ] Identify mock data before replacing it with live API calls.
- [ ] Document every endpoint, request shape, response shape, loading state, and error state before wiring.
- [ ] Verify live wiring in a browser with console/network checks before marking complete.

## Side-effect policy

No external writes, billing actions, user messaging, or destructive mutations without explicit user approval.
