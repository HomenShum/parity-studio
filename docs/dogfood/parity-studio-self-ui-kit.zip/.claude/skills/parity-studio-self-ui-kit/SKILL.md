---
name: parity-parity-studio-self-ui-kit
description: Use this skill when integrating, verifying, or iterating the parity-studio-self-ui-kit Parity Studio ui_kit. Read the operating contract, performance budget, API wiring plan, and QA plan before editing.
---

# Parity Studio parity-studio-self-ui-kit

Follow this workflow:

1. Read `ui_kits/parity-studio-self-ui-kit/parity.contract.json`.
2. Read `ui_kits/parity-studio-self-ui-kit/performance.budget.json`, `api-wiring.plan.md`, and `qa.plan.md`.
3. Classify the request as appearance, performance, organization, api, accessibility, or privacy.
4. Edit the smallest relevant files under `ui_kits/parity-studio-self-ui-kit/`.
5. Run static checks and live browser QA when the host app is available.
6. Update the contract/plans when assumptions changed; otherwise state "no contract change".

Never expose BYOK provider keys. Local MCP keys stay in local env only.
