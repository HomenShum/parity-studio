# Agent instructions for parity-studio-self-ui-kit

This repository contains a Parity Studio ui_kit export. Treat
`ui_kits/parity-studio-self-ui-kit/parity.contract.json` as the source of truth for
intent, parity, performance, API wiring, QA, and BYOK/privacy policy.

Required workflow:

1. Read the contract before edits.
2. Classify impact: appearance, performance, organization, api, accessibility, or privacy.
3. Keep edits scoped to the requested surface.
4. Preserve visible source text, labels, and numbers unless the user explicitly changes copy.
5. Update contract/plans when assumptions change, or state "no contract change".
6. Verify with lint plus live browser QA when the host app is runnable.

Security:

- Do not read, print, commit, or upload provider API keys.
- Local MCP BYOK keys stay in local env/config and are never sent to Parity Studio.
- Ask for approval before hosted uploads of private route captures or external side effects.
